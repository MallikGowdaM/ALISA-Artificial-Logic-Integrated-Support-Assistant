import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Lottie from "lottie-react";
import arcAnim from "./assets/arc.json";

export default function ArcReactor() {
  const [showInput, setShowInput] = useState(false);
  const [wakeWord, setWakeWord] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const correctWakeWord = "jarvis";

  const handleWakeWord = (e) => {
    if (e.key === "Enter") {
      if (wakeWord.toLowerCase() === correctWakeWord.toLowerCase()) {
        navigate("/dashboard");
      } else {
        setError("❌ Wrong wake word!");
      }
    }
  };

  return (
    <div className="w-screen h-screen flex items-center justify-center bg-black relative">
      {/* Arc Reactor JSON centered */}
      <div className="cursor-pointer" onClick={() => setShowInput(true)}>
        <Lottie
          animationData={arcAnim}
          loop
          style={{
            width: "600px",   // ✅ fixed width (adjust as needed)
            height: "auto",   // ✅ keeps proportions
          }}
        />
      </div>

      {/* Wake Word Input */}
      {showInput && (
        <div className="absolute flex flex-col items-center justify-center">
          <input
            type="text"
            placeholder="Enter Wake Word..."
            className="p-3 rounded text-black w-72 text-center border-2 border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-500 bg-white/90"
            value={wakeWord}
            onChange={(e) => setWakeWord(e.target.value)}
            onKeyDown={handleWakeWord}
            autoFocus
          />
          {error && <p className="text-red-500 mt-3">{error}</p>}
        </div>
      )}
    </div>
  );
}
