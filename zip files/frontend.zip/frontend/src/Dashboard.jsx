import React, { useEffect, useState } from "react";
import Lottie from "lottie-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

export default function Dashboard() {
  const [robotAnim, setRobotAnim] = useState(null);
  const [showWelcome, setShowWelcome] = useState(true); // control welcome popup
  const navigate = useNavigate();

  useEffect(() => {
    fetch("/robot.json")
      .then((res) => res.json())
      .then((data) => setRobotAnim(data));

    // Hide welcome message after 3 seconds
    const timer = setTimeout(() => setShowWelcome(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  const logout = () => {
    toast.info("🚪 Logged out successfully!");
    navigate("/");
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden">
      {robotAnim && (
        <Lottie
          animationData={robotAnim}
          loop
          className="absolute inset-0 w-full h-full object-cover"
        />
      )}

      {/* Dark overlay */}
      <div className="absolute inset-0 bg-black/40"></div>

      {/* Welcome popup (disappears after 3s) */}
      {showWelcome && (
        <div className="absolute inset-0 flex items-center justify-center">
          <h2 className="text-4xl font-bold text-white drop-shadow-lg animate-fadeInOut">
            Welcome to Dashboard 🎉
          </h2>
        </div>
      )}

      {/* Logout button in bottom-right */}
      <button
        className="absolute bottom-6 right-6 bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-xl text-lg transition"
        onClick={logout}
      >
        Logout
      </button>
    </div>
  );
}
