GEMINI_API_KEY="AIzaSyAgR7bVJwMpB5v921aokQ0Tx57e6LrTPOw"
BRAVE_BINARY_PATH = r"C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
BRAVE_DRIVER_PATH=r"D:\chromedriver-win64\chromedriver.exe"
WEATHER_API_KEY="6f10ef2cd3627d982df38ee9b469dd6e"
EMAIL_ADDRESS = "crazybeast7022@gmail.com"
EMAIL_PASSWORD = "brse vmnw ntzp hejc"
SERPAPI_KEY = "4e90d018df22a54b44c6f00c85341c091a81fa2611a8645393609cb999c59cdc"

