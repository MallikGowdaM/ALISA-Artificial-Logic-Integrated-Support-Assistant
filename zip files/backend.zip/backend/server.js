import express from "express";
import sqlite3 from "sqlite3";
import { open } from "sqlite";
import cors from "cors";
import bodyParser from "body-parser";

const app = express();
app.use(cors());
app.use(bodyParser.json());

const db = await open({
  filename: "./database.db",
  driver: sqlite3.Database,
});

// 🚨 Reset table (drop + recreate)
await db.exec(`DROP TABLE IF EXISTS users`);

await db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password TEXT
  )
`);

app.post("/signup", async (req, res) => {
  const { username, email, phone, password } = req.body;

  try {
    await db.run(
      "INSERT INTO users (username, email, phone, password) VALUES (?, ?, ?, ?)",
      [username, email, phone, password]
    );
    res.json({ success: true, message: "Signup successful" });
  } catch (err) {
    res.json({ success: false, message: "Account already exists" });
  }
});

app.post("/login", async (req, res) => {
  const { identifier, password } = req.body; // can be email or username

  const user = await db.get(
    "SELECT * FROM users WHERE (email = ? OR username = ?) AND password = ?",
    [identifier, identifier, password]
  );

  if (user) {
    res.json({ success: true });
  } else {
    res.json({ success: false, message: "Invalid credentials" });
  }
});

const PORT = 4000;
app.listen(PORT, () =>
  console.log(`✅ Backend running on http://localhost:${PORT}`)
);
