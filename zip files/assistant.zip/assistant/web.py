import os
import webbrowser
import pywhatkit
import requests
from speech import speak
from config import GEMINI_API_KEY, CHROME_DRIVER_PATH, BRAVE_DRIVER_PATH, WEATHER_API_KEY
from deep_translator import GoogleTranslator

# -----------------------------
# Helper: Translate text
# -----------------------------
def translate_text(text, lang):
    try:
        if lang == "hi":
            return GoogleTranslator(source="auto", target="hi").translate(text)
        elif lang == "kn":
            return GoogleTranslator(source="auto", target="kn").translate(text)
        else:
            return text
    except Exception as e:
        print(f"Translation error: {e}")
        return text

# -----------------------------
# Register Brave browser if available
# -----------------------------
def _get_browser():
    try:
        webbrowser.register('chrome', None, webbrowser.BackgroundBrowser(CHROME_DRIVER_PATH))
        return 'chrome'
    except:
        return None

# -----------------------------
# Weather Fetch
# -----------------------------
def get_weather(city_name, lang="en"):
    try:
        # Translate city name into English for API call
        if lang in ["hi", "kn"]:
            city_name_en = GoogleTranslator(source="auto", target="en").translate(city_name)
        else:
            city_name_en = city_name

        base_url = "http://api.openweathermap.org/data/2.5/weather?"
        complete_url = f"{base_url}q={city_name_en}&appid={WEATHER_API_KEY}&units=metric"

        response = requests.get(complete_url)
        weather_data = response.json()

        if weather_data.get("cod") != 200:
            message = weather_data.get("message", "City not found")
            if lang == "hi":
                speak(f"त्रुटि: {message}", lang)
            elif lang == "kn":
                speak(f"ದೋಷ: {message}", lang)
            else:
                speak(f"Error: {message}", lang)
            return

        temp = weather_data["main"]["temp"]
        weather_desc = weather_data["weather"][0]["description"]
        humidity = weather_data["main"]["humidity"]
        wind_speed = weather_data["wind"]["speed"]

        if lang == "hi":
            report = f"{city_name} में वर्तमान तापमान {temp} डिग्री सेल्सियस है, मौसम {weather_desc} है, आर्द्रता {humidity}% और हवा की गति {wind_speed} मीटर प्रति सेकंड है।"
        elif lang == "kn":
            report = f"{city_name} ನಲ್ಲಿ ಪ್ರಸ್ತುತ ತಾಪಮಾನ {temp} ಡಿಗ್ರಿ ಸೆಲ್ಸಿಯಸ್, ಹವಾಮಾನ {weather_desc}, ತೇವಾಂಶ {humidity}% ಮತ್ತು ಗಾಳಿಯ ವೇಗ {wind_speed} ಮೀಟರ್ ಪ್ರತಿ ಸೆಕೆಂಡ್."
        else:
            report = f"The current temperature in {city_name} is {temp}°C with {weather_desc}. Humidity is {humidity}% and wind speed is {wind_speed} m/s."

        speak(report, lang)

    except Exception as e:
        print(f"Exception: {e}")
        if lang == "hi":
            speak("माफ़ कीजिए, मैं मौसम रिपोर्ट नहीं ला सका।", lang)
        elif lang == "kn":
            speak("ಕ್ಷಮಿಸಿ, ನಾನು ಹವಾಮಾನ ವರದಿಯನ್ನು ತರಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.", lang)
        else:
            speak("Sorry, I couldn't fetch the weather report.", lang)