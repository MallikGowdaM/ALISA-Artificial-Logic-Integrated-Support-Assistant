import os
import subprocess
import time
import ollama
import pyautogui
import re
from speech import speak, takecommand
import smtplib
from email.mime.text import MIMEText
from keywords import CONTACTS
import spotipy
from spotipy.oauth2 import SpotifyOAuth

def send_whatsapp_message(cmd="", lang="en"):
    """
    Send WhatsApp message via Desktop.
    - Supports one-shot: "send whatsapp message to Kiran and say hi"
    - If contact not found → retries once
    """
    try:
        contact_name = None
        message = None

        # 🔍 Parse one-shot command
        match = re.search(r"send whatsapp (?:message )?to (.+?) (?:saying|and say|say) (.+)", cmd, re.IGNORECASE)
        if match:
            contact_name = match.group(1).strip()
            message = match.group(2).strip()

        # --- Get contact interactively if missing ---
        attempts = 0
        while not contact_name and attempts < 2:
            speak("To whom should I send the WhatsApp message?", lang)
            contact_name = takecommand(lang).lower().strip()
            if contact_name == "none" or not contact_name:
                contact_name = None
                attempts += 1
        if not contact_name:
            speak("Sorry, I couldn't get the contact name.", lang)
            return

        # --- Get message interactively if missing ---
        attempts = 0
        while not message and attempts < 2:
            speak(f"What message should I send to {contact_name}?", lang)
            message = takecommand(lang)
            if message == "none" or not message:
                message = None
                attempts += 1
        if not message:
            speak("Sorry, I couldn't get the message.", lang)
            return

        # === Function to search and send ===
        def try_send(contact_name, message):
            # 🚀 Open WhatsApp Desktop
            os.system("start whatsapp:")
            time.sleep(6)

            # 🔎 Search contact
            pyautogui.hotkey("ctrl", "f")
            time.sleep(1)
            pyautogui.write(contact_name)
            time.sleep(2)

            # Try selecting first result
            pyautogui.press("down")
            time.sleep(1)
            pyautogui.press("enter")
            time.sleep(2)

            # Small check: if no chat opened, WhatsApp stays in search box
            # Workaround: check if typing works in chat box
            pyautogui.typewrite(" ")
            time.sleep(1)
            pyautogui.press("backspace")

            # ✉️ Send message
            pyautogui.write(message)
            time.sleep(1)
            pyautogui.press("enter")

            # Close WhatsApp
            os.system("taskkill /f /im WhatsApp.exe")
            return True

        # First attempt
        speak("Opening WhatsApp", lang)
        try:
            try_send(contact_name, message)
            speak(f"Message sent to {contact_name}.", lang)
            return
        except Exception:
            # Close if failed
            os.system("taskkill /f /im WhatsApp.exe")

        # Retry once
        speak("I could not find the contact. Please say the name again.", lang)
        contact_name = takecommand(lang).lower().strip()
        if contact_name == "none" or not contact_name:
            speak("Sorry, contact name not found.", lang)
            return

        try:
            try_send(contact_name, message)
            speak(f"Message sent to {contact_name}.", lang)
        except Exception:
            os.system("taskkill /f /im WhatsApp.exe")
            speak("Sorry, I still couldn’t find that contact.", lang)

    except Exception as e:
        speak(f"Something went wrong: {e}", lang)



# ⚠️ Configure your Gmail here
SENDER_EMAIL = "crazybeast7022@gmail.com"
SENDER_PASSWORD = "brse vmnw ntzp hejc"  # Use App Password from Google

def extract_name_from_email(email: str) -> str:
    """Extract a clean name from the email ID (ignores numbers)."""
    username = email.split("@")[0]
    clean_name = re.sub(r"\d+", "", username)  # remove numbers
    if not clean_name:
        return "User"
    return clean_name.capitalize()


def ask_gemma_for_email(subject: str, sender_name: str) -> str:
    """Use Gemma ONLY to generate an email body."""
    prompt = f"""
    Write a short professional email about: {subject}.
    - Start with 'Dear Sir/Madam,'
    - 3 to 4 sentences only.
    - End with 'Best regards, {sender_name}'
    """

    try:
        response = ollama.chat(
            model="gemma:2b",
            messages=[{"role": "user", "content": prompt}]
        )
        body = response["message"]["content"].strip()

        if body:
            speak("Email body generated using Gemma model.")
            return body
        else:
            speak("Sorry, Gemma did not return any output.")
            return "[Error: No output from Gemma]"

    except Exception as e:
        speak(f"Gemma error: {e}")
        return f"[Error: {e}]"


def send_email(lang="en"):
    """Send an email via Gmail. Uses Gemma ONLY for body generation."""
    try:
        sender_name = extract_name_from_email(SENDER_EMAIL)

        # --- Receiver ---
        speak("Whom should I send the email to?", lang)
        receiver = takecommand(lang).lower().replace(" ", "")
        if receiver == "none" or not receiver:
            speak("I couldn't get the receiver name.", lang)
            return

        if receiver in CONTACTS:
            receiver_email = CONTACTS[receiver]
        elif "@" in receiver:
            receiver_email = receiver
        else:
            receiver_email = f"{receiver}@gmail.com"

        speak(f"Sending email to {receiver_email}.", lang)

        # --- Subject ---
        speak("What is the subject?", lang)
        subject = takecommand(lang)
        if subject == "none" or not subject:
            speak("I couldn’t get the subject.", lang)
            return

        # --- Body ---
        speak("Will you say the message content, or should I generate it using AI?", lang)
        choice = takecommand(lang).lower()

        if "say" in choice or "bol" in choice or "heli" in choice:
            speak("Okay, please say the message content now.", lang)
            body = takecommand(lang)
            if body == "none" or not body:
                speak("I couldn’t catch the message. I will generate it using AI instead.", lang)
                body = ask_gemma_for_email(subject, sender_name)
        else:
            speak("Okay, I will generate the message using AI.", lang)
            body = ask_gemma_for_email(subject, sender_name)

        # --- Construct & send ---
        msg = MIMEText(body, "plain")
        msg["Subject"] = subject
        msg["From"] = SENDER_EMAIL
        msg["To"] = receiver_email

        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login(SENDER_EMAIL, SENDER_PASSWORD)
            server.sendmail(SENDER_EMAIL, receiver_email, msg.as_string())

        speak(f"Email has been sent to {receiver}.", lang)

    except Exception as e:
        speak(f"Something went wrong: {e}", lang)

# Spotify credentials
SPOTIFY_CLIENT_ID = "28a58dadea464478b747932555238d3b"
SPOTIFY_CLIENT_SECRET = "579ac7436e784509bd1a09fa0d2da0e6"
SPOTIFY_REDIRECT_URI = "http://127.0.0.1:8000/callback"

# Initialize Spotipy
sp = spotipy.Spotify(auth_manager=SpotifyOAuth(
    client_id=SPOTIFY_CLIENT_ID,
    client_secret=SPOTIFY_CLIENT_SECRET,
    redirect_uri=SPOTIFY_REDIRECT_URI,
    scope="user-read-playback-state,user-modify-playback-state,app-remote-control,streaming"
))


# 🚀 Ensure Spotify is running (launch + minimize)
def play_song_on_spotify(song, lang="en"):
    try:
        # Search multiple results
        results = sp.search(q=song, type="track", limit=10)
        tracks = results.get("tracks", {}).get("items", [])

        song_lower = song.lower()

        chosen_track = None

        # Case 1: "song by artist"
        if " by " in song_lower:
            parts = song_lower.split(" by ")
            title = parts[0].strip()
            artist = parts[1].strip()

            for t in tracks:
                track_name = t["name"].lower()
                artist_names = [a["name"].lower() for a in t["artists"]]
                if track_name == title and any(artist in a for a in artist_names):
                    chosen_track = t
                    break

        # Case 2: Only song title
        else:
            for t in tracks:
                if t["name"].lower() == song_lower:
                    chosen_track = t
                    break

        if chosen_track:
            track_name = chosen_track["name"]
            artist_name = chosen_track["artists"][0]["name"]
            track_uri = chosen_track["uri"]   # spotify:track:xxxxxx

            # Open in Spotify desktop app
            subprocess.Popen(["cmd", "/c", "start", track_uri], shell=True)

            if lang == "en":
                speak(f"Playing {track_name} by {artist_name} on Spotify app.", lang="en")
            elif lang == "hi":
                speak(f"{track_name} स्पॉटिफ़ाई ऐप पर चला रहा हूँ।", lang="hi")
            elif lang == "kn":
                speak(f"{track_name} ಸ್ಪಾಟಿಫೈ ಆ್ಯಪ್‌ನಲ್ಲಿ ಪ್ಲೇ ಮಾಡುತ್ತಿದ್ದೇನೆ.", lang="kn")

        else:
            if lang == "en":
                speak("Sorry, I could not find that exact song on Spotify.", lang="en")
            elif lang == "hi":
                speak("माफ़ कीजिए, वह गाना स्पॉटिफ़ाई पर नहीं मिला।", lang="hi")
            elif lang == "kn":
                speak("ಕ್ಷಮಿಸಿ, ಆ ಹಾಡು ಸ್ಪಾಟಿಫೈನಲ್ಲಿ ಸಿಗಲಿಲ್ಲ.", lang="kn")

    except Exception as e:
        print("Spotify Error:", e)
        if lang == "en":
            speak("Something went wrong while trying to play in Spotify app.", lang="en")
        elif lang == "hi":
            speak("स्पॉटिफ़ाई ऐप पर गाना चलाने में समस्या हुई।", lang="hi")
        elif lang == "kn":
            speak("ಸ್ಪಾಟಿಫೈ ಆ್ಯಪ್‌ನಲ್ಲಿ ಹಾಡು ಪ್ಲೇ ಮಾಡುವಲ್ಲಿ ದೋಷ ಉಂಟಾಯಿತು.", lang="kn")

def close_spotify(lang="en"):
    try:
        os.system("taskkill /f /im Spotify.exe")
        if lang == "en":
            speak("Spotify has been closed.", lang)
        elif lang == "hi":
            speak("स्पॉटिफ़ाई बंद कर दिया गया है।", lang)
        elif lang == "kn":
            speak("ಸ್ಪಾಟಿಫೈ ಮುಚ್ಚಲಾಗಿದೆ.", lang)
    except Exception as e:
        print("Close Spotify Error:", e)
        if lang == "en":
            speak("I couldn't close Spotify.", lang)
        elif lang == "hi":
            speak("मैं स्पॉटिफ़ाई को बंद नहीं कर सका।", lang)
        elif lang == "kn":
            speak("ನಾನು ಸ್ಪಾಟಿಫೈ ಮುಚ್ಚಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.", lang)


