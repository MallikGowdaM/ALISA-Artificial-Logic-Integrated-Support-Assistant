import google.generativeai as genai

# Replace with your actual API key
GEMINI_API_KEY = "AIzaSyAZPbvmZRONgrgAp4-Zx3VxaJ_UY3aSFTs"

# Configure the API key
genai.configure(api_key=GEMINI_API_KEY)

try:
    # Generate text using the Gemini 2.5 Flash-Lite model
    response = genai.generate_text(
        model="models/gemini-2.5-flash-lite",
        prompt="What is the capital of France?"
    )

    print("API Call Successful!")
    print(response["candidates"][0]["content"])

except Exception as e:
    print("An error occurred during the API call:")
    print(e)

