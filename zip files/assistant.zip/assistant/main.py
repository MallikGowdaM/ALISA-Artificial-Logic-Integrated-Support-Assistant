import datetime
import sys
import time
import webbrowser
import socketio
from ai import ask_ai
from file import open_file_interactive, create_folder, create_file
from planning import plan_trip_interactive, study_timetable_interactive
from reminder import list_reminders, delete_reminder, clear_all_reminders, handle_reminder
from social import send_whatsapp_message, send_email, play_song_on_spotify
from speech import wish, speak as base_speak, takecommand as base_takecommand
from apps import open_app, close_app   # ✅ unified apps
from system import shutdown_pc, restart_pc, sleep, lock, system_status, open_camera, switch_window, minimize_window, \
    switch_tab, get_ip_address
from keywords import KEYWORDS
from web import get_weather
from phone_control import pick_call, reject_call, handle_emergency_message, handle_emergency_call

WAKE_WORDS = ["jarvis", "assistant", "hey jarvis"]

sio = socketio.Client()
sio.connect("http://localhost:4000")


def emit_status(status, **kwargs):
    """Send assistant status or command info to frontend"""
    try:
        payload = {"status": status}
        payload.update(kwargs)
        sio.emit("assistant_status", payload)
    except Exception as e:
        print(f"Socket emit failed: {e}", flush=True)


# ✅ NEW speak wrapper
def speak(text, lang="en"):
    """Wrapper around base_speak that also updates frontend"""
    try:
        emit_status("assistant_reply", reply_text=text)
        emit_status("assistant_command", command_text=text)
        base_speak(text, lang=lang)
    finally:
        emit_status("idle")

def takecommand(lang="en"):
    """Wrapper around base_takecommand with frontend emit"""
    emit_status("listening")
    text = base_takecommand(lang)
    emit_status("idle")

    if text and text != "None":
        emit_status("user_command", command_text=text)
    return text

# -----------------------------
# Language selection
# -----------------------------
def ask_language():
    speak("Which language should I assist you in? English, Hindi or Kannada?", lang="en")
    while True:
        lang_choice = takecommand("en")
        if "english" in lang_choice:
            speak("Okay, I will assist you in English.", lang="en")
            emit_status("idle")
            return "en"
        elif "hindi" in lang_choice or "हिंदी" in lang_choice:
            speak("ठीक है, अब मैं हिंदी में बात करूंगा।", lang="hi")
            emit_status("idle")
            return "hi"
        elif "kannada" in lang_choice or "ಕನ್ನಡ" in lang_choice:
            speak("ಸರಿ, ನಾನು ಈಗ ಕನ್ನಡದಲ್ಲಿ ಮಾತನಾಡುತ್ತೇನೆ.", lang="kn")
            emit_status("idle")
            return "kn"
        else:
            speak("Sorry, please say English, Hindi or Kannada.", lang="en")
            emit_status("idle")


# -----------------------------
# Main
# -----------------------------
def main():
    speak("Hello! I am your assistant. Say the wake word to start.", lang="en")
    # emit_status("idle")
    active_lang = "en"

    while True:
        emit_status("listening")  # ✅ start listening
        query = takecommand("en")  # Wake words always in English
        emit_status("idle")
        if any(w in query for w in WAKE_WORDS):
            emit_status("reset")
            print("WAKEWORD_DETECTED", flush=True)  # ✅ Node catches this
            active_lang = ask_language()
            wish(active_lang)
            emit_status("idle")

            while True:
                cmd = takecommand(active_lang)
                emit_status("idle")
                if cmd == "None":
                    continue
                print(f"Handling ({active_lang}): {cmd}")
                emit_status("assistant_command", command_text=cmd)
                # -----------------------------
                # CHANGE LANGUAGE
                # -----------------------------
                if any(kw in cmd for kw in KEYWORDS["change_lang"][active_lang]):
                    active_lang = ask_language()
                    return active_lang

                # -----------------------------
                # GOOGLE SEARCH
                # -----------------------------
                elif ("google" in cmd and (
                        any(kw in cmd for kw in KEYWORDS["web_search"][active_lang]) or
                        cmd.strip().startswith("google") or
                        cmd.strip().startswith("गूगल") or
                        cmd.strip().startswith("ಗೂಗಲ್")
                )):
                    query = cmd.replace("google", "").replace("on google", "").replace("गूगल", "").replace("ಗೂಗಲ್",
                                                                                                           "").strip()
                    if query:
                        emit_status("assistant_command", command_text=f"⚡ Searching {query} on Google")
                        open_app("google", active_lang, query=query)
                    else:
                        speak("What should I search on Google?", active_lang)
                        emit_status("idle")
                        q = takecommand(active_lang)
                        if q != "None":
                            open_app("google", active_lang, query=q)

                # -----------------------------
                # YOUTUBE PLAY
                # -----------------------------
                elif ("youtube" in cmd and (
                        any(kw in cmd for kw in KEYWORDS["youtube_play"][active_lang]) or
                        cmd.strip().startswith("youtube") or
                        cmd.strip().startswith("यूट्यूब") or
                        cmd.strip().startswith("ಯೂಟ್ಯೂಬ್")
                )):
                    query = cmd.replace("youtube", "").replace("on youtube", "").replace("यूट्यूब", "").replace(
                        "ಯೂಟ್ಯೂಬ್",
                        "").strip()
                    if query:
                        emit_status("assistant_command", command_text=f"⚡ Playing {query} on YouTube")
                        open_app("youtube", active_lang, query=query)
                    else:
                        speak("What should I play on YouTube?", active_lang)
                        emit_status("idle")
                        q = takecommand(active_lang)
                        if q != "None":
                            open_app("youtube", active_lang, query=q)

                # -----------------------------
                # NORMAL OPEN (system/web)
                # -----------------------------
                elif any(cmd.startswith(kw) for kw in KEYWORDS["open"][active_lang]):
                    for kw in KEYWORDS["open"][active_lang]:
                        if cmd.startswith(kw):
                            app = cmd.replace(kw, "").strip()
                            emit_status("assistant_command", command_text=f"⚡ Opening {app}")
                            open_app(app, active_lang)
                            break

                # -----------------------------
                # CLOSE (system/web)
                # -----------------------------
                elif any(cmd.startswith(kw) for kw in KEYWORDS["close"][active_lang]):
                    for kw in KEYWORDS["close"][active_lang]:
                        if cmd.startswith(kw):
                            app = cmd.replace(kw, "").strip()
                            emit_status("assistant_command", command_text=f"⚡ Closing {app}")
                            close_app(app, active_lang)
                            break

                # -----------------------------
                # WINDOW & TAB CONTROLS
                # -----------------------------
                elif "switch window" in cmd:
                    emit_status("assistant_command", command_text="⚡ Switching window")
                    switch_window(active_lang)
                elif "minimize window" in cmd:
                    emit_status("assistant_command", command_text="⚡ Minimizing window")
                    minimize_window(active_lang)
                elif "next tab" in cmd or "switch tab" in cmd:
                    emit_status("assistant_command", command_text="⚡ Switching browser tab")
                    switch_tab(True, active_lang)
                elif "previous tab" in cmd:
                    emit_status("assistant_command", command_text="⚡ Switching browser tab")
                    switch_tab(True, active_lang)
                elif "ip address" in cmd or "my ip" in cmd:
                    emit_status("assistant_command", command_text="⚡ Searching IP Addrerss")
                    get_ip_address(active_lang)

                # -----------------------------
                # WEATHER
                # -----------------------------
                elif "weather" in cmd or "मौसम" in cmd or "ಹವಾಮಾನ" in cmd:
                    city = None
                    if active_lang == "hi":
                        city = cmd.replace("मौसम", "").replace("का", "").replace("बताओ", "").strip()
                    elif active_lang == "kn":
                        city = cmd.replace("ಹವಾಮಾನ", "").replace("ವರದಿ", "").replace("ಏನು", "").strip()
                    else:
                        words = cmd.split()
                        for i, w in enumerate(words):
                            if w in ["in", "at"] and i + 1 < len(words):
                                city = " ".join(words[i + 1:])
                                break
                    if not city:
                        speak("Which city?", lang=active_lang)
                        emit_status("idle")
                        city = takecommand(active_lang)
                    emit_status("assistant_command", command_text=f"⚡ Fetching weather for {city}")
                    get_weather(city, active_lang)


                # -----------------------------
                # STOP
                # -----------------------------
                elif any(kw in cmd for kw in KEYWORDS["stop"][active_lang]):
                    emit_status("assistant_command", command_text="⚡ Stopping assistant")
                    speak("Goodbye. Just say the wake word when you need me.", lang=active_lang)
                    emit_status("idle")
                    print("EXIT_DETECTED", flush=True)
                    exit(0)



                # -----------------------------
                # FILE HANDLING
                # -----------------------------
                elif cmd.startswith("open file"):
                    emit_status("assistant_command", command_text=f"⚡ Opening file {cmd}")
                    open_file_interactive(cmd, active_lang)
                elif cmd.startswith("create file"):
                    emit_status("assistant_command", command_text=f"⚡ Creating file {cmd}")
                    create_file(cmd)
                elif cmd.startswith("create folder"):
                    emit_status("assistant_command", command_text=f"⚡ Creating folder {cmd}")
                    create_folder(cmd)

                # -----------------------------
                # CAMERA
                # -----------------------------
                elif "open camera" in cmd:
                    emit_status("assistant_command", command_text="⚡ Opening camera")
                    open_camera(active_lang)
                elif "close camera" in cmd:
                    speak("You can close camera by saying 'close camera' inside the camera window.", active_lang)
                    emit_status("idle")

                # -----------------------------
                # POWER COMMANDS
                # -----------------------------
                elif any(kw in cmd for kw in KEYWORDS["shutdown"][active_lang]):
                    emit_status("assistant_command", command_text="⚡ Shutting down PC")
                    shutdown_pc(active_lang)
                elif any(kw in cmd for kw in KEYWORDS["restart"][active_lang]):
                    emit_status("assistant_command", command_text="⚡ Restarting PC")
                    restart_pc(active_lang)
                elif any(kw in cmd for kw in KEYWORDS["sleep"][active_lang]):
                    emit_status("assistant_command", command_text="⚡ Putting PC to sleep")
                    sleep(active_lang)
                elif any(kw in cmd for kw in KEYWORDS["lock"][active_lang]):
                    emit_status("assistant_command", command_text="⚡ Locking PC")
                    lock(active_lang)

                elif any(kw in cmd for kw in KEYWORDS["status"][active_lang]):
                    emit_status("assistant_command", command_text="⚡ Checking system status")
                    system_status(active_lang)


                # -----------------------------
                # PLANNING
                # -----------------------------
                elif "study" in cmd:
                    emit_status("assistant_command", command_text="⚡ Preparing study timetable")
                    study_timetable_interactive(active_lang, speak, takecommand)

                elif "plan my trip" in cmd:
                    emit_status("assistant_command", command_text="⚡ Planning your trip")
                    plan_trip_interactive(active_lang, speak, takecommand)

                # -----------------------------
                # TIME
                # -----------------------------
                elif any(kw in cmd for kw in KEYWORDS["time"][active_lang]):
                    strTime = datetime.datetime.now().strftime("%H:%M:%S")
                    emit_status("assistant_command", command_text="⚡ Telling current time")
                    speak(f"The time is {strTime}", lang=active_lang)
                    emit_status("idle")

                # -----------------------------
                # AI ANSWERS
                # -----------------------------
                elif any(cmd.startswith(q) for q in KEYWORDS["question"]["en"] +
                                                    KEYWORDS["question"]["hi"] +
                                                    KEYWORDS["question"]["kn"]):
                    emit_status("assistant_command", command_text="⚡ Asking AI for answer")
                    answer, detected_lang = ask_ai(cmd)
                    speak(answer, lang=detected_lang)
                    emit_status("idle")

                # -----------------------------
                # COMMUNICATION
                # -----------------------------
                elif "send whatsapp" in cmd:
                    emit_status("assistant_command", command_text="⚡ Sending WhatsApp message")
                    send_whatsapp_message(cmd, active_lang)

                elif "send email" in cmd or "ईमेल भेजो" in cmd or "ಇಮೇಲ್ ಕಳುಹಿಸಿ" in cmd:
                    emit_status("assistant_command", command_text="⚡ Sending email")
                    send_email(active_lang)


                # -----------------------------
                # SPOTIFY
                # -----------------------------
                elif any(kw in cmd for kw in KEYWORDS["spotify_play"][active_lang]):
                    query = cmd
                    for kw in KEYWORDS["spotify_play"][active_lang]:
                        query = query.replace(kw, "").strip()
                    if not query or query.lower() in ["song", "music", "spotify"]:
                        speak("Which song should I play?", lang=active_lang)
                        song_name = takecommand(active_lang)
                        if song_name != "None":
                            emit_status("assistant_command", command_text=f"⚡ Playing {query} on Spotify")
                            play_song_on_spotify(query, active_lang)

                    else:
                        play_song_on_spotify(query, active_lang)

                elif any(kw in cmd for kw in KEYWORDS["spotify_close"][active_lang]):
                    from social import close_spotify
                    emit_status("assistant_command", command_text="⚡ Closing Spotify")
                    close_spotify(active_lang)


                # -----------------------------
                # CALLS
                # -----------------------------
                elif "pick call" in cmd or "answer call" in cmd:
                    emit_status("assistant_command", command_text="⚡ Picking up call")
                    pick_call(active_lang)

                elif "reject call" in cmd or "cut call" in cmd:
                    emit_status("assistant_command", command_text="⚡ Rejecting call")
                    reject_call(active_lang)

                elif "emergency message" in cmd:
                    emit_status("assistant_command", command_text="⚡ Handling emergency message")
                    handle_emergency_message(cmd, takecommand, active_lang)

                elif "emergency call" in cmd:
                    emit_status("assistant_command", command_text="⚡ Handling emergency call")
                    handle_emergency_call(cmd, takecommand, active_lang)


                # -----------------------------
                # REMINDERS
                # -----------------------------
                elif "set a reminder" in cmd or "remind me" in cmd:
                    emit_status("assistant_command", command_text="⚡ Setting a reminder")
                    handle_reminder(cmd, takecommand, active_lang)

                elif "my reminders" in cmd:
                    emit_status("assistant_command", command_text="⚡ Listing all reminders")
                    list_reminders(active_lang)

                elif "delete reminder" in cmd:
                    speak("Which reminder should I delete?", active_lang)
                    emit_status("idle")
                    task = takecommand(active_lang)
                    if task != "None":
                        emit_status("assistant_command", command_text="⚡ Deleting a reminder")
                        delete_reminder(task, active_lang)

                elif "clear reminders" in cmd:
                    emit_status("assistant_command", command_text="⚡ Clearing all reminders")
                    clear_all_reminders(active_lang)


                # -----------------------------
                # FALLBACK
                # -----------------------------
                else:
                    speak("Sorry, I didn’t understand that.", lang=active_lang)
                    emit_status("idle")

                emit_status("command_end", command_text=cmd)


if __name__ == "__main__":
        main()