# ai.py
import requests
from deep_translator import GoogleTranslator
from langdetect import detect
import subprocess
import os
import datetime
from docx import Document
import ollama   # ✅ Missing import added

# 🔑 SerpAPI Key (replace with your own or set as ENV variable)
SERPAPI_KEY = os.getenv(
    "SERPAPI_KEY",
    "4e90d018df22a54b44c6f00c85341c091a81fa2611a8645393609cb999c59cdc"
)

# ------------------ DuckDuckGo ------------------ #
def ask_duckduckgo(question: str) -> str:
    """Query DuckDuckGo Instant Answer API (no key required)."""
    try:
        url = "https://api.duckduckgo.com/"
        params = {"q": question, "format": "json", "no_html": 1, "skip_disambig": 1}
        r = requests.get(url, params=params, timeout=5)
        data = r.json()

        if data.get("AbstractText"):
            return data["AbstractText"]
        elif data.get("Answer"):
            return data["Answer"]
        elif data.get("Heading"):
            return data["Heading"]
        else:
            return ""
    except requests.Timeout:
        return "DuckDuckGo search took too long. Try again."
    except Exception as e:
        return f"DuckDuckGo error: {e}"

# ------------------ SerpAPI ------------------ #
def ask_serpapi(question: str) -> str:
    """Query SerpAPI (requires free API key)."""
    try:
        url = "https://serpapi.com/search"
        params = {"q": question, "hl": "en", "api_key": SERPAPI_KEY}
        r = requests.get(url, params=params, timeout=5).json()

        if "answer_box" in r:
            if "answer" in r["answer_box"]:
                return r["answer_box"]["answer"]
            if "snippet" in r["answer_box"]:
                return r["answer_box"]["snippet"]

        if "knowledge_graph" in r and "title" in r["knowledge_graph"]:
            return r["knowledge_graph"]["title"]

        if "organic_results" in r and len(r["organic_results"]) > 0:
            return r["organic_results"][0].get("snippet", "")

        return "No direct answer found."
    except requests.Timeout:
        return "SerpAPI search took too long. Try again."
    except Exception as e:
        return f"SerpAPI error: {e}"

# ------------------ Web Search Helper ------------------ #
def search_web_for_answer(query: str) -> str:
    """Use SerpAPI for realtime answers (fallback if needed)."""
    try:
        url = "https://serpapi.com/search"
        params = {"q": query, "api_key": SERPAPI_KEY, "engine": "google"}
        response = requests.get(url, params=params, timeout=5)
        data = response.json()

        if "answer_box" in data:
            if "answer" in data["answer_box"]:
                return data["answer_box"]["answer"]
            elif "snippet" in data["answer_box"]:
                return data["answer_box"]["snippet"]
            elif "highlighted_words" in data["answer_box"]:
                return ", ".join(data["answer_box"]["highlighted_words"])

        if "organic_results" in data and "snippet" in data["organic_results"][0]:
            return data["organic_results"][0]["snippet"]

        return "Sorry, I couldn't find a reliable answer."
    except requests.Timeout:
        return "The search took too long. Try again."
    except Exception as e:
        return f"Web search error: {e}"

# ------------------ Language Detection & Translation ------------------ #
def detect_language(text: str) -> str:
    """Detect language code ('en', 'hi', 'kn')."""
    try:
        lang = detect(text)
        if lang.startswith("hi"):
            return "hi"
        elif lang.startswith("kn"):
            return "kn"
        else:
            return "en"
    except Exception:
        return "en"

def translate_text(text: str, target_lang: str) -> str:
    """Translate text using deep-translator (Google)."""
    try:
        lang_map = {"hi": "hi", "kn": "kn"}
        if target_lang in lang_map:
            return GoogleTranslator(source="auto", target=lang_map[target_lang]).translate(text)
        return text
    except Exception:
        return text

# ------------------ AI Query Wrapper ------------------ #
def ask_ai(question: str) -> tuple[str, str]:
    """
    Main AI query function.
    Returns (answer, lang) where lang is detected language of user.
    """
    lang = detect_language(question)

    # Try DuckDuckGo first
    answer = ask_duckduckgo(question)

    # Fallback to SerpAPI
    if not answer or answer.startswith("DuckDuckGo error"):
        if SERPAPI_KEY and SERPAPI_KEY != "YOUR_SERPAPI_KEY":
            answer = ask_serpapi(question)

    if not answer:
        answer = "Sorry, I couldn’t find an answer for that."

    # Translate if needed
    if lang in ["hi", "kn"]:
        answer = translate_text(answer, lang)

    return answer, lang

# ------------------ Gemma Model ------------------ #
def ask_gemma(prompt: str) -> str:
    """
    Query Gemma model.
    Uses web search for realtime queries, otherwise Ollama.
    """
    realtime_keywords = [
        "current", "today", "latest", "now", "who is", "when",
        "president", "prime minister", "CM of", "weather"
    ]

    if any(keyword in prompt.lower() for keyword in realtime_keywords):
        return search_web_for_answer(prompt)

    try:
        response = ollama.chat(
            model="gemma:2b",
            messages=[{"role": "user", "content": f"You are a friendly voice assistant. {prompt}"}]
        )
        return response["message"]["content"].strip()
    except Exception as e:
        print(f"Gemma error: {e}")
        return "Sorry, I couldn't process your question."
