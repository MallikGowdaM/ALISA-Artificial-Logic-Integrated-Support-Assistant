# keywords.py

KEYWORDS = {
    "open": {
        "en": ["open", "start"],
        "hi": ["खोलो", "स्टार्ट"],
        "kn": ["ತೆರೆ", "ಪ್ರಾರಂಭಿಸು"]
    },
    "close": {
        "en": ["close",  "stop"],
        "hi": ["बंद", "बंद करो"],
        "kn": ["ಮುಚ್ಚು", "ಮುಚ್ಚುಹಾಕು"]
    },
    "shutdown": {
        "en": ["shutdown", "power off"],
        "hi": ["शटडाउन", "कंप्यूटर बंद करो"],
        "kn": ["ಶಟ್‌ಡೌನ್", "ಆಫ್ ಮಾಡು"]
    },
    "restart": {
        "en": ["restart", "reboot"],
        "hi": ["रीस्टार्ट", "पुनः आरंभ"],
        "kn": ["ಮರುಪ್ರಾರಂಭ", "ರೀಸ್ಟಾರ್ಟ್"]
    },
    "sleep": {
        "en": ["sleep", "standby"],
        "hi": ["स्लीप", "सो जाओ"],
        "kn": ["ನಿದ್ರೆ", "ಸ್ಲೀಪ್"]
    },
    "lock": {
        "en": ["lock", "secure"],
        "hi": ["लॉक", "ताला"],
        "kn": ["ಲಾಕ್", "ತಾಳೆ"]
    },
    "time": {
        "en": ["time", "current time", "what time"],
        "hi": ["समय", "टाइम"],
        "kn": ["ಸಮಯ"]
    },
    "status": {
        "en": ["status", "system status"],
        "hi": ["स्थिति", "सिस्टम स्थिति"],
        "kn": ["ಸ್ಥಿತಿ", "ಸಿಸ್ಟಮ್ ಸ್ಥಿತಿ"]
    },
    "stop": {
        "en": ["stop", "exit", "quit"],
        "hi": ["रुको", "बंद करो सहायक", "बंद"],
        "kn": ["ನಿಲ್ಲಿಸು", "ಸಹಾಯಕ ಮುಚ್ಚು", "ಮುಚ್ಚು"]
    },
    "change_lang": {
        "en": ["change language", "switch language"],
        "hi": ["भाषा बदलो", "भाषा बदलना"],
        "kn": ["ಭಾಷೆ ಬದಲಾಯಿಸಿ", "ಭಾಷೆ ಬದಲಿಸು"]
    },
    # ------------------------
    # Web Apps
    # ------------------------
    "web_open": {
        "en": ["google", "youtube", "instagram", "facebook"],
        "hi": ["गूगल", "यूट्यूब", "इंस्टाग्राम", "फेसबुक"],
        "kn": ["ಗೂಗಲ್", "ಯೂಟ್ಯೂಬ್", "ಇನ್ಸ್ಟಾಗ್ರಾಮ್", "ಫೇಸ್ಬುಕ್"]
    },
    "web_search": {
        "en": ["search", "look up", "find"],
        "hi": ["खोजो", "ढूंढो", "सर्च करो"],
        "kn": ["ಹುಡುಕಿ", "ಹುಡುಕು", "ಸರ್ಚ್"]
    },
    "youtube_play": {
        "en": ["play", "watch"],
        "hi": ["चलाओ", "देखो"],
        "kn": ["ಪ್ಲೇ", "ನೋಡು"]
    },
    "web_close": {
        "en": ["close browser", "close google", "close youtube", "close facebook", "close instagram"],
        "hi": ["ब्राउज़र बंद करो", "गूगल बंद करो", "यूट्यूब बंद करो", "फेसबुक बंद करो", "इंस्टाग्राम बंद करो"],
        "kn": ["ಬ್ರೌಸರ್ ಮುಚ್ಚಿ", "ಗೂಗಲ್ ಮುಚ್ಚಿ", "ಯೂಟ್ಯೂಬ್ ಮುಚ್ಚಿ", "ಫೇಸ್ಬುಕ್ ಮುಚ್ಚಿ", "ಇನ್ಸ್ಟಾಗ್ರಾಮ್ ಮುಚ್ಚಿ"]
    },
    # ------------------------
    # Questions
    # ------------------------
    "question": {
        "en": ["who", "when", "where", "what", "why", "how"],
        "hi": ["कौन", "कब", "कहाँ", "क्या", "कैसे"],
        "kn": ["ಯಾರು", "ಯಾವಾಗ", "ಎಲ್ಲಿ", "ಏನು", "ಹೇಗೆ"]
    },
    # ------------------------
    # Spotify
    # ------------------------
    "spotify_play": {
        "en": ["play", "play song", "spotify", "play music"],
        "hi": ["गाना चलाओ", "गीत चलाओ", "संगीत चलाओ", "स्पॉटिफ़ाई"],
        "kn": ["ಹಾಡು ಪಾಡು", "ಹಾಡು ನುಡಿಸು", "ಸಂಗೀತ ಬಾರಿಸು", "ಸ್ಪಾಟಿಫೈ"]
    },
    "spotify_close": {
        "en": ["close spotify", "exit spotify", "stop spotify app"],
        "hi": ["स्पॉटिफ़ाई बंद करो", "स्पॉटिफ़ाई ऐप बंद करो"],
        "kn": ["ಸ್ಪಾಟಿಫೈ ಮುಚ್ಚಿ", "ಸ್ಪಾಟಿಫೈ ಆಪ್ ಮುಚ್ಚಿ"]
    }
}

# Contacts
CONTACTS = {
    "boss": "boss.company@gmail.com",
    "dad": "mallikgowdam8@gmail.com",
    "friend": "rahul123@gmail.com",
    "teacher": "teacher.name@gmail.com",
}

EMERGENCY_CONTACTS = {
    "ghost": "6362632172",
    "kiran": "7411470549",
    "brother": "9123456789",
    "police": "100",
    "ambulance": "108"
}
