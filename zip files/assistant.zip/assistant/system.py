# system.py
import datetime
import os, subprocess, psutil
import socket

import cv2
import pyautogui
import requests

from speech import speak, takecommand

def system_status(lang="en"):
    cpu = psutil.cpu_percent()
    ram = psutil.virtual_memory().percent
    disk = psutil.disk_usage('/').percent
    battery = psutil.sensors_battery()

    if lang == "hi":
        message = f"सी पी यू {cpu} प्रतिशत, रैम {ram} प्रतिशत, डिस्क {disk} प्रतिशत।"
        if battery: message += f" बैटरी {battery.percent} प्रतिशत।"
        speak(message, lang="hi")
    elif lang == "kn":
        message = f"ಸಿಪಿಯು {cpu} ಶೇಕಡಾ, ರಾಮ್ {ram} ಶೇಕಡಾ, ಡಿಸ್ಕ್ {disk} ಶೇಕಡಾ."
        if battery: message += f" ಬ್ಯಾಟರಿ {battery.percent} ಶೇಕಡಾ."
        speak(message, lang="kn")
    else:
        message = f"CPU {cpu}% RAM {ram}% Disk {disk}%."
        if battery: message += f" Battery {battery.percent}%"
        speak(message, lang="en")

def shutdown_pc(lang="en"):
    os.system("shutdown /s /t 5")
    if lang == "hi":
        speak("सिस्टम शटडाउन हो रहा है।", lang="hi")
    elif lang == "kn":
        speak("ಸಿಸ್ಟಮ್ ಶಟ್ ಡೌನ್ ಆಗುತ್ತಿದೆ.", lang="kn")
    else:
        speak("Shutting down the system.", lang="en")

def restart_pc(lang="en"):
    os.system("shutdown /r /t 5")
    if lang == "hi":
        speak("सिस्टम रीस्टार्ट हो रहा है।", lang="hi")
    elif lang == "kn":
        speak("ಸಿಸ್ಟಮ್ ಮರುಪ್ರಾರಂಭಗೊಳ್ಳುತ್ತಿದೆ.", lang="kn")
    else:
        speak("Restarting the system.", lang="en")

def sleep(lang="en"):
    os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
    if lang == "hi":
        speak("सिस्टम स्लीप मोड में जा रहा है।", lang="hi")
    elif lang == "kn":
        speak("ಸಿಸ್ಟಮ್ ನಿದ್ರಾ ಸ್ಥಿತಿಗೆ ಹೋಗುತ್ತಿದೆ.", lang="kn")
    else:
        speak("Putting system to sleep.", lang="en")

def lock(lang="en"):
    os.system("rundll32.exe user32.dll,LockWorkStation")
    if lang == "hi":
        speak("सिस्टम लॉक हो गया है।", lang="hi")
    elif lang == "kn":
        speak("ಸಿಸ್ಟಮ್ ಲಾಕ್ ಮಾಡಲಾಗಿದೆ.", lang="kn")
    else:
        speak("Locking the system.", lang="en")

# -----------------------------
# Camera Control
# -----------------------------
def open_camera(lang="en"):
    cmp = cv2.VideoCapture(0)
    if not cmp.isOpened():
        speak("Camera could not be opened.", lang)
        return
    if lang == "hi":
        speak("कैमरा चालू है। 'फोटो खींचो' कहें फोटो खींचने के लिए, या 'कैमरा बंद करो' कहें बंद करने के लिए।", lang)
    elif lang == "kn":
        speak("ಕ್ಯಾಮೆರಾ ತೆರೆಯಲಾಗಿದೆ. 'ಫೋಟೋ ತೆಗೆಯಿರಿ' ಎಂದು ಹೇಳಿ ಅಥವಾ 'ಕ್ಯಾಮೆರಾ ಮುಚ್ಚಿ' ಎಂದು ಹೇಳಿ.", lang)
    else:
        speak("Camera is open. Say 'click photo' to capture, or 'close camera' to exit.", lang)
    while True:
        ret, img = cmp.read()
        if not ret:
            speak("Failed to grab frame.", lang)
            break
        cv2.imshow('Webcam', img)
        cv2.waitKey(1)
        try:
            command = takecommand(lang).lower()
            if "click photo" in command or "take photo" in command:
                timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
                img_path = f"captured_{timestamp}.png"
                cv2.imwrite(img_path, img)
                speak("Photo saved.", lang)
            elif "close camera" in command or "exit camera" in command:
                speak("Closing camera now.", lang)
                break
        except Exception:
            continue
    cmp.release()
    cv2.destroyAllWindows()


# -----------------------------
# Window Controls
# -----------------------------
def switch_window(lang="en"):
    """Switch between open windows (Alt+Tab)."""
    pyautogui.keyDown("alt")
    pyautogui.press("tab")
    pyautogui.keyUp("alt")
    if lang == "hi":
        speak("विंडो बदल दी गई है।", lang)
    elif lang == "kn":
        speak("ವಿಂಡೋ ಬದಲಾಯಿಸಲಾಗಿದೆ.", lang)
    else:
        speak("Switched window.", lang)

def minimize_window(lang="en"):
    """Minimize current window (Win+Down)."""
    pyautogui.hotkey("win", "down")
    if lang == "hi":
        speak("विंडो छोटा कर दिया गया है।", lang)
    elif lang == "kn":
        speak("ವಿಂಡೋ ಸಣ್ಣದಾಗಿದೆ.", lang)
    else:
        speak("Window minimized.", lang)

# -----------------------------
# Browser Tab Controls
# -----------------------------
def switch_tab(next=True, lang="en"):
    """Switch between browser tabs (Ctrl+Tab / Ctrl+Shift+Tab)."""
    if next:
        pyautogui.hotkey("ctrl", "tab")
    else:
        pyautogui.hotkey("ctrl", "shift", "tab")
    if lang == "hi":
        speak("टैब बदल दिया गया है।", lang)
    elif lang == "kn":
        speak("ಟ್ಯಾಬ್ ಬದಲಾಯಿಸಲಾಗಿದೆ.", lang)
    else:
        speak("Switched tab.", lang)

def get_ip_address(lang="en"):
    """Get and speak the system's IP address (local + public)."""
    try:
        # Local IP
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)

        # Public IP
        public_ip = requests.get("https://api.ipify.org").text
    except Exception as e:
        if lang == "hi":
            speak("आई पी पता प्राप्त करने में त्रुटि हुई।", lang)
        elif lang == "kn":
            speak("ಐಪಿ ವಿಳಾಸ ಪಡೆಯುವಲ್ಲಿ ದೋಷವಾಗಿದೆ.", lang)
        else:
            speak("Error getting IP address.", lang)
        return

    if lang == "hi":
        speak(f"आपका लोकल आई पी {local_ip} है और पब्लिक आई पी {public_ip} है।", lang)
    elif lang == "kn":
        speak(f"ನಿಮ್ಮ ಸ್ಥಳೀಯ ಐಪಿ {local_ip}, ಮತ್ತು ಸಾರ್ವಜನಿಕ ಐಪಿ {public_ip} ಆಗಿದೆ.", lang)
    else:
        speak(f"Your local IP is {local_ip}, and your public IP is {public_ip}.", lang)

